-- BGCommsUI.lua - Create the button frame and BGCommsUI elements
-- Note: BGCommsCommunications, BGCommsLocations, BGCommsMacros, Settings are loaded globally by WoW before this file

BGCommsUI = {}
BGCommsUI.frame = nil
BGCommsUI.backgroundTexture = nil
BGCommsUI.macroButtons = {}
BGCommsUI.lockButton = nil
BGCommsUI.opacityMinusButton = nil
BGCommsUI.opacityPlusButton = nil
BGCommsUI.gearButton = nil
BGCommsUI.minimapIcon = nil

-- Toggle frame lock
function BGCommsUI:ToggleLock()
    if not BGCommsDB then return end

    BGCommsDB.isLocked = not BGCommsDB.isLocked
    self:ApplyLockState()
end

-- Apply lock state to frame
function BGCommsUI:ApplyLockState()
    if not self.frame or not BGCommsDB then return end

    local isLocked = BGCommsDB.isLocked

    if isLocked then
        self.frame:SetMovable(false)
        if self.lockButton then
            self.lockButton:SetText("🔒")
        end
    else
        self.frame:SetMovable(true)
        if self.lockButton then
            self.lockButton:SetText("🔓")
        end
    end
end

-- Adjust background opacity
function BGCommsUI:AdjustOpacity(delta)
    if not BGCommsDB then return end

    local currentOpacity = BGCommsDB.backgroundOpacity or 0.5
    local newOpacity = currentOpacity + delta

    -- Clamp to 0.1 - 1.0 range
    if newOpacity < 0.1 then
        newOpacity = 0.1
    elseif newOpacity > 1.0 then
        newOpacity = 1.0
    end

    BGCommsDB.backgroundOpacity = newOpacity
    self:ApplyOpacity()
end

-- Apply opacity to frame background
function BGCommsUI:ApplyOpacity()
    if not self.backgroundTexture then return end
    local opacity = BGCommsDB and BGCommsDB.backgroundOpacity or 0.5
    self.backgroundTexture:SetAlpha(opacity)
end

-- Create minimap icon
function BGCommsUI:CreateMinimapIcon()
    if self.minimapIcon then return end

    local icon = CreateFrame("Button", "BGCommsMinimapIcon", Minimap)
    icon:SetSize(32, 32)
    icon:SetFrameLevel(8)
    icon:SetFrameStrata("MEDIUM")

    -- Restore position or use default (top-right of minimap)
    local iconX = BGCommsDB and BGCommsDB.minimapIconX or -70
    local iconY = BGCommsDB and BGCommsDB.minimapIconY or 70
    icon:SetPoint("TOPRIGHT", Minimap, "TOPRIGHT", iconX, iconY)

    -- Icon texture (Battle Shout icon)
    local iconTexture = icon:CreateTexture(nil, "OVERLAY")
    iconTexture:SetAllPoints(icon)
    iconTexture:SetTexture("Interface/Icons/Ability_Warrior_BattleShout")

    -- Make draggable
    icon:SetMovable(true)
    icon:EnableMouse(true)
    icon:RegisterForDrag("LeftButton")
    icon:SetScript("OnDragStart", function(dragFrame)
        dragFrame:StartMoving()
    end)
    icon:SetScript("OnDragStop", function(dragFrame)
        dragFrame:StopMovingOrSizing()
        -- Save minimap icon position using GetPoint()
        if BGCommsDB then
            local _, _, _, x, y = dragFrame:GetPoint()
            if x and y then
                BGCommsDB.minimapIconX = x
                BGCommsDB.minimapIconY = y
            end
        end
    end)

    -- Click to toggle settings
    icon:SetScript("OnClick", function()
        BGCommsSettingsPanel:ToggleFrame()
    end)

    -- Hover tooltip
    icon:SetScript("OnEnter", function(frame)
        GameTooltip:SetOwner(frame, "ANCHOR_LEFT")
        GameTooltip:SetText("BG Comms Settings", 1, 1, 1)
        GameTooltip:AddLine("Click to open settings", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)

    icon:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    self.minimapIcon = icon
end

-- Create macro buttons dynamically
function BGCommsUI:CreateMacroButtons(parentFrame, startY)
    -- Clear existing macro buttons
    for _, button in ipairs(self.macroButtons) do
        button:Hide()
    end
    self.macroButtons = {}

    local macros = BGCommsMacros:GetMacros()
    local buttonIndex = 1

    for macroName, _ in pairs(macros) do
        local macroButton = CreateFrame("Button", "BGMacroButton" .. buttonIndex, parentFrame, "GameMenuButtonTemplate")
        macroButton:SetSize(80, 25)

        -- Position buttons in two columns
        local column = (buttonIndex - 1) % 2
        local row = math.floor((buttonIndex - 1) / 2)

        if column == 0 then
            macroButton:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 10, startY - (row * 30))
        else
            macroButton:SetPoint("LEFT", parentFrame, "TOPLEFT", 100, startY - (row * 30))
        end

        macroButton:SetText(macroName:sub(1, 8))  -- Limit text to 8 chars
        macroButton:SetScript("OnClick", function()
            BGCommsMacros:ExecuteMacro(macroName)
        end)

        table.insert(self.macroButtons, macroButton)
        buttonIndex = buttonIndex + 1
    end

    -- Adjust frame height if needed
    local totalRows = math.ceil(#self.macroButtons / 2)
    if totalRows > 0 then
        parentFrame:SetHeight(100 + (totalRows * 30))
    end
end

function BGCommsUI:CreateFrame()
    if self.frame then return end

    -- Create main frame
    local frame = CreateFrame("Frame", "BGCommsFrame", UIParent)
    frame:SetSize(200, 100)

    -- Position frame at center (don't use saved absolute coordinates as offsets)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)

    -- Create background texture for opacity control
    local bgTexture = frame:CreateTexture(nil, "BACKGROUND")
    bgTexture:SetAllPoints(frame)
    bgTexture:SetColorTexture(0, 0, 0, 0.5)
    self.backgroundTexture = bgTexture

    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:SetScript("OnMouseDown", function(dragFrame, button)
        -- Only allow dragging if frame is not locked
        if button == "LeftButton" and (not BGCommsDB or not BGCommsDB.isLocked) then
            dragFrame:StartMoving()
        end
    end)
    frame:SetScript("OnMouseUp", function(dragFrame)
        dragFrame:StopMovingOrSizing()
        -- Save window position to SavedVariables
        if BGCommsDB then
            BGCommsDB.windowX = dragFrame:GetLeft()
            BGCommsDB.windowY = dragFrame:GetTop()
        end
    end)

    -- Title
    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", frame, "TOP", 0, -10)
    title:SetText("BG Comms")

    -- Gear/Settings button
    local gearButton = CreateFrame("Button", "BGGearButton", frame, "GameMenuButtonTemplate")
    gearButton:SetSize(25, 25)
    gearButton:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -25)
    gearButton:SetText("⚙")
    gearButton:SetScript("OnClick", function()
        BGCommsSettingsPanel:ToggleFrame()
    end)

    -- Opacity minus button
    local opacityMinusButton = CreateFrame("Button", "BGOpacityMinusButton", frame, "GameMenuButtonTemplate")
    opacityMinusButton:SetSize(25, 25)
    opacityMinusButton:SetPoint("LEFT", gearButton, "RIGHT", 2, 0)
    opacityMinusButton:SetText("-")
    opacityMinusButton:SetScript("OnClick", function()
        self:AdjustOpacity(-0.1)
    end)

    -- Opacity plus button
    local opacityPlusButton = CreateFrame("Button", "BGOpacityPlusButton", frame, "GameMenuButtonTemplate")
    opacityPlusButton:SetSize(25, 25)
    opacityPlusButton:SetPoint("LEFT", opacityMinusButton, "RIGHT", 2, 0)
    opacityPlusButton:SetText("+")
    opacityPlusButton:SetScript("OnClick", function()
        self:AdjustOpacity(0.1)
    end)

    -- Lock button
    local lockButton = CreateFrame("Button", "BGLockButton", frame, "GameMenuButtonTemplate")
    lockButton:SetSize(30, 25)
    lockButton:SetPoint("LEFT", opacityPlusButton, "RIGHT", 5, 0)
    lockButton:SetText("🔓")
    lockButton:SetScript("OnClick", function()
        self:ToggleLock()
    end)

    self.gearButton = gearButton
    self.lockButton = lockButton
    self.opacityMinusButton = opacityMinusButton
    self.opacityPlusButton = opacityPlusButton

    -- CLEAR button
    local clearButton = CreateFrame("Button", "BGClearButton", frame, "GameMenuButtonTemplate")
    clearButton:SetSize(80, 25)
    clearButton:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -55)
    clearButton:SetText("CLEAR")
    clearButton:SetScript("OnClick", function()
        BGCommsCommunications:SendClear()
    end)

    -- INC button
    local incButton = CreateFrame("Button", "BGIncButton", frame, "GameMenuButtonTemplate")
    incButton:SetSize(80, 25)
    incButton:SetPoint("LEFT", clearButton, "RIGHT", 10, 0)
    incButton:SetText("INC")
    incButton:SetScript("OnClick", function()
        local location = BGCommsLocations:GetPlayerLocation()
        BGCommsCommunications:SendIncoming(location)
    end)

    self.frame = frame
    self.clearButton = clearButton
    self.incButton = incButton

    -- Create macro buttons (starting below CLEAR/INC buttons)
    self:CreateMacroButtons(frame, -80)

    -- Create minimap icon
    self:CreateMinimapIcon()

    -- Apply saved lock state
    self:ApplyLockState()

    -- Apply saved opacity
    self:ApplyOpacity()

end

function BGCommsUI:ToggleFrame()
    if self.frame then
        if self.frame:IsShown() then
            self.frame:Hide()
        else
            self.frame:Show()
        end
    else
        local success, err = pcall(function()
            self:CreateFrame()
        end)
        if success then
            self.frame:Show()
        else
            print("|cFFFF0000[BGComms]|r ERROR creating main frame: " .. tostring(err))
        end
    end
end

function BGCommsUI:Hide()
    if self.frame then
        self.frame:Hide()
    end
end

function BGCommsUI:Show()
    if not self.frame then
        self:CreateFrame()
    end
    self.frame:Show()
end

-- Refresh the BGCommsUI (e.g., when macros are added/removed)
function BGCommsUI:RefreshUI()
    if self.frame then
        self:CreateMacroButtons(self.frame, -30)
    end
end
