-- Settings.lua - Settings panel BGCommsUI and management
-- Note: BGCommsCommunications and BGCommsUI are loaded globally by WoW before this file
-- RENAMED: BGCommsSettingsPanel to avoid conflict with Blizzard's global Settings object

BGCommsSettingsPanel = {}
BGCommsSettingsPanel.frame = nil
BGCommsSettingsPanel.channelDropdown = nil
BGCommsSettingsPanel.opacityValue = nil
BGCommsSettingsPanel.lockCheckbox = nil
BGCommsSettingsPanel.smartChannelCheckbox = nil

function BGCommsSettingsPanel:CreateFrame()
    BGCommsLogger:Debug("CreateFrame (settings) called, frame exists: " .. tostring(self.frame ~= nil))
    if self.frame then return end

    BGCommsLogger:Debug("Creating settings frame object...")
    -- Create settings frame
    local frame = CreateFrame("Frame", "BGCommsSettingsFrame", UIParent)
    BGCommsLogger:Debug("Settings frame object created: " .. tostring(frame))
    frame:SetSize(250, 280)

    -- Restore position from SavedVariables or use defaults
    local posX = BGCommsDB and BGCommsDB.settingsPanelX or -100
    local posY = BGCommsDB and BGCommsDB.settingsPanelY or 0
    frame:SetPoint("CENTER", UIParent, "CENTER", posX, posY)

    -- SetBackdrop calls are deprecated in WoW Midnight 12.0 and removed
    -- frame:SetBackdrop({
    --     bgFile = "Interface/Tooltips/BGCommsUI-Tooltip-Background",
    --     edgeFile = "Interface/Tooltips/BGCommsUI-Tooltip-Border",
    --     tile = true,
    --     tileSize = 16,
    --     edgeSize = 16,
    --     insets = { left = 4, right = 4, top = 4, bottom = 4 }
    -- })
    -- frame:SetBackdropColor(0, 0, 0, 0.7)
    -- frame:SetBackdropBorderColor(1, 1, 1, 0.8)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", function(dragFrame)
        dragFrame:StopMovingOrSizing()
        -- Save settings panel position
        if BGCommsDB then
            BGCommsDB.settingsPanelX = dragFrame:GetLeft()
            BGCommsDB.settingsPanelY = dragFrame:GetTop()
        end
    end)
    frame:Hide()  -- Hidden by default

    -- Title
    local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", frame, "TOP", 0, -10)
    title:SetText("BG Comms Settings")

    -- Close button
    local closeButton = CreateFrame("Button", "BGSettingsCloseButton", frame, "GameMenuButtonTemplate")
    closeButton:SetSize(25, 25)
    closeButton:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -5, -5)
    closeButton:SetText("X")
    closeButton:SetScript("OnClick", function()
        self:Hide()
    end)

    -- Channel selection label
    local channelLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    channelLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -40)
    channelLabel:SetText("Channel:")

    -- Channel dropdown (simple text display for now)
    local channelDropdown = CreateFrame("Button", "BGChannelDropdown", frame, "GameMenuButtonTemplate")
    channelDropdown:SetSize(200, 25)
    channelDropdown:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -60)
    channelDropdown:SetText(BGCommsCommunications:GetChatChannel())
    channelDropdown:SetScript("OnClick", function()
        self:ShowChannelMenu()
    end)
    self.channelDropdown = channelDropdown

    -- Opacity label
    local opacityLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    opacityLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -100)
    opacityLabel:SetText("Opacity:")

    -- Opacity minus button
    local opacityMinus = CreateFrame("Button", "BGSettingsOpacityMinus", frame, "GameMenuButtonTemplate")
    opacityMinus:SetSize(30, 25)
    opacityMinus:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -120)
    opacityMinus:SetText("-")
    opacityMinus:SetScript("OnClick", function()
        BGCommsUI:AdjustOpacity(-0.1)
        self:UpdateOpacityDisplay()
    end)

    -- Opacity value display
    local opacityValue = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    opacityValue:SetPoint("LEFT", opacityMinus, "RIGHT", 10, 0)
    opacityValue:SetText("0.5")
    self.opacityValue = opacityValue

    -- Opacity plus button
    local opacityPlus = CreateFrame("Button", "BGSettingsOpacityPlus", frame, "GameMenuButtonTemplate")
    opacityPlus:SetSize(30, 25)
    opacityPlus:SetPoint("LEFT", opacityValue, "RIGHT", 10, 0)
    opacityPlus:SetText("+")
    opacityPlus:SetScript("OnClick", function()
        BGCommsUI:AdjustOpacity(0.1)
        self:UpdateOpacityDisplay()
    end)

    -- Lock toggle label
    local lockLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    lockLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -160)
    lockLabel:SetText("Lock Window:")

    -- Lock toggle checkbox
    local lockCheckbox = CreateFrame("CheckButton", "BGSettingsLockCheckbox", frame, "ChatConfigCheckButtonTemplate")
    lockCheckbox:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -180)
    lockCheckbox:SetScript("OnClick", function(self)
        BGCommsUI:ToggleLock()
        self:SetChecked(BGCommsDB.isLocked)
    end)
    self.lockCheckbox = lockCheckbox

    -- Smart Channel label
    local smartLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    smartLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -210)
    smartLabel:SetText("Smart Channel:")

    -- Smart Channel checkbox
    local smartCheckbox = CreateFrame("CheckButton", "BGSettingsSmartCheckbox", frame, "ChatConfigCheckButtonTemplate")
    smartCheckbox:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -230)
    smartCheckbox:SetScript("OnClick", function(self)
        BGCommsDB.useSmartChannelDetection = self:GetChecked()
    end)
    self.smartChannelCheckbox = smartCheckbox

    self.frame = frame
    self:UpdateAllSettings()
end

-- Update all settings display from SavedVariables
function BGCommsSettingsPanel:UpdateAllSettings()
    BGCommsLogger:Debug("UpdateAllSettings called")
    if not self.frame then
        BGCommsLogger:Debug("UpdateAllSettings: frame is nil!")
        return
    end

    BGCommsLogger:Debug("Updating channel dropdown...")
    self:UpdateChannelDropdown()
    BGCommsLogger:Debug("Updating opacity display...")
    self:UpdateOpacityDisplay()
    BGCommsLogger:Debug("Updating lock display...")
    self:UpdateLockDisplay()
    BGCommsLogger:Debug("Updating smart channel display...")
    self:UpdateSmartChannelDisplay()
    BGCommsLogger:Debug("UpdateAllSettings complete")
end

function BGCommsSettingsPanel:UpdateChannelDropdown()
    if self.channelDropdown then
        self.channelDropdown:SetText(BGCommsCommunications:GetChatChannel())
    end
end

function BGCommsSettingsPanel:UpdateOpacityDisplay()
    if self.opacityValue then
        local opacity = BGCommsDB and BGCommsDB.backgroundOpacity or 0.5
        self.opacityValue:SetText(string.format("%.1f", opacity))
    end
end

function BGCommsSettingsPanel:UpdateLockDisplay()
    if self.lockCheckbox then
        self.lockCheckbox:SetChecked(BGCommsDB.isLocked)
    end
end

function BGCommsSettingsPanel:UpdateSmartChannelDisplay()
    if self.smartChannelCheckbox then
        self.smartChannelCheckbox:SetChecked(BGCommsDB.useSmartChannelDetection)
    end
end

function BGCommsSettingsPanel:ShowChannelMenu()
    -- Create a dropdown menu for channel selection
    local menu = {
        {
            text = "BGCOMMS",
            func = function()
                BGCommsCommunications:SetChatChannel("BGCOMMS")
                self:UpdateChannelDropdown()
            end
        },
        {
            text = "PARTY",
            func = function()
                BGCommsCommunications:SetChatChannel("PARTY")
                self:UpdateChannelDropdown()
            end
        },
        {
            text = "RAID",
            func = function()
                BGCommsCommunications:SetChatChannel("RAID")
                self:UpdateChannelDropdown()
            end
        },
        {
            text = "BATTLEGROUND",
            func = function()
                BGCommsCommunications:SetChatChannel("BATTLEGROUND")
                self:UpdateChannelDropdown()
            end
        },
        {
            text = "SAY",
            func = function()
                BGCommsCommunications:SetChatChannel("SAY")
                self:UpdateChannelDropdown()
            end
        },
    }

    EasyMenu(menu, CreateFrame("Frame", "BGChannelMenu", UIParent, "UIDropDownMenuTemplate"), "cursor", 0, 0, "TOPLEFT")
end

function BGCommsSettingsPanel:ToggleFrame()
    BGCommsLogger:Debug("Settings ToggleFrame called, frame exists: " .. tostring(self.frame ~= nil))
    if self.frame then
        if self.frame:IsShown() then
            BGCommsLogger:Debug("Hiding settings")
            self:Hide()
        else
            BGCommsLogger:Debug("Showing settings")
            self:Show()
        end
    else
        BGCommsLogger:Debug("Creating settings frame...")
        local success, err = pcall(function()
            self:CreateFrame()
        end)
        BGCommsLogger:Debug("pcall returned, success: " .. tostring(success))
        if success then
            BGCommsLogger:Debug("Settings frame created, showing...")
            BGCommsLogger:Debug("self.frame = " .. tostring(self.frame))
            self:Show()
            BGCommsLogger:Debug("After Show(), frame visible: " .. tostring(self.frame:IsVisible()))
        else
            BGCommsLogger:Error("ERROR creating settings frame: " .. tostring(err))
        end
    end
end

function BGCommsSettingsPanel:Show()
    if not self.frame then
        self:CreateFrame()
    end
    self:UpdateAllSettings()
    self.frame:Show()
end

function BGCommsSettingsPanel:Hide()
    if self.frame then
        self.frame:Hide()
    end
end
